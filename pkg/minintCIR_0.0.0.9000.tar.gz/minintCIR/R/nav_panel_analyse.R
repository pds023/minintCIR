

#' Title
#'
#' @return
#' @export
#'
#' @examples
nav_panel_analyse <- function() {
return(nav_panel("Exploration",icon = bs_icon("search")))
}
